
# Define the built-in server protocol "manual".
#
(function() {
    ngchmCreateServerProtocol ("manual");
})();
